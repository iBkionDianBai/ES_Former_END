# npm install -g yarn

安装 yarn

## 先运行 yarn install

安装项目所需的依赖库。这将根据项目中的 package.json 文件自动安装所有依赖项。

## yarn start

运行项目

# 当前进展
1.新增了一个Footer
2.修改了当前的页面架构，所有页面前端代码架构统一。


